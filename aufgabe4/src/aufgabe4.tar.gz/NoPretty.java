
public class NoPretty extends BlockPretty {
	
	public NoPretty() { 
		super(0);
	}
}
